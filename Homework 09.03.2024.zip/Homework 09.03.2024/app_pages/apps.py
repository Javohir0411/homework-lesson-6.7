from django.apps import AppConfig


class AppPagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_pages'
