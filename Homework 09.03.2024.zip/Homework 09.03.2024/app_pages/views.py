from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return HttpResponse("<h1>Hello World, You are at the  Home page</h1>"
                        "<h2><a style='text-decoration: none' href='about/'>About Page</a></h2>")


def about(request):
    return HttpResponse("<h1> Hello World, You are at the  About page </h1>"
                        "<h2><a style='text-decoration: none' href='index/'>Home Page</a></h2>"
                        "<h2><a style='text-decoration: none' href='contact/'>Contact Page</a></h2>")


def contact(request):
    return HttpResponse("<h1> Welcome To Contact Page</h1>"
                        "<h2><a style='text-decoration: none' href='about/'>About Page</a></h2>"
                        "<h2><a style='text-decoration: none' href='store/'>Store Page</a></h2>")


def store(request):
    return HttpResponse("<h1> Welcome To Store Page</h1>"
                        "<h2><a style='text-decoration: none' href='contact/'>Contact Page</a></h2>"
                        "<h2><a style='text-decoration: none' href='setting/'>Setting Page</a></h2>")


def setting(request):
    return HttpResponse("<h1> Welcome To Contact Page</h1>"
                        "<h2><a style='text-decoration: none' href='index/'>Home Page</a></h2>"
                        "<h2><a style='text-decoration: none' href='store/'>Store Page</a></h2>")
